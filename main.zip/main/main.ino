#include "myBLE.h"
// #include "myOLED.h"

#include <arduino.h>
#include <ESP32Servo.h>
#include <Wire.h>

int liftoff_time = 0;
bool BLEable = false;

Servo servo00;  //MG92B
const int servo00_pin = 16;
const int servo00_open = 500;
const int servo00_close = 1000;
int servo00_value = servo00_close;
bool servo00_ctrl = true;
Servo servo01;  //N.C.
const int servo01_pin = 17;
const int servo01_open = 500;
const int servo01_close = 1000;
int servo01_value = servo01_close;
bool servo01_ctrl = true;
Servo servo02;  //MG996R
const int servo02_pin = 4;
const int servo02_open = 500;
const int servo02_close = 1055;
int servo02_value = servo02_close;
bool servo02_ctrl = true;
Servo servo03;  //MG996R
const int servo03_pin = 27;
const int servo03_open = 500;
const int servo03_close = 1055;
int servo03_value = servo03_close;
bool servo03_ctrl = true;

const int flight_pin = 14;
bool flight = true;

const int signal_pin00 = 25;
bool signal00 = false;
const int signal_pin01 = 26;
bool signal01 = false;

const int status_pin00 = 2;
bool status00 = false;
const int status_pin01 = 13;
bool status01 = false;

void BLEdisable(){
  BLEable = false;
  servo00_ctrl = false;
  servo01_ctrl = false;
  servo02_ctrl = false;
  servo03_ctrl = false;
}
void ARM(){
  servo00.writeMicroseconds(servo00_close);
  servo01.writeMicroseconds(servo01_close);
  servo02.writeMicroseconds(servo02_close);
  servo03.writeMicroseconds(servo03_close);
  servo00_ctrl = false;
  servo01_ctrl = false;
  servo02_ctrl = false;
  servo03_ctrl = false;
  status00 = false;
  status01 = false;
}

void DISARM(){
  servo00.writeMicroseconds(servo00_open);
  servo01.writeMicroseconds(servo01_open);
  servo02.writeMicroseconds(servo02_open);
  servo03.writeMicroseconds(servo03_open);
}

void PREPARATION() {
  BLEable = true;
  servo00.writeMicroseconds(servo00_value);
  servo01.writeMicroseconds(servo01_value);
  servo02.writeMicroseconds(servo02_value);
  servo03.writeMicroseconds(servo03_value);
}

void STANDBY() {
  BLEdisable();
  ARM();
}

void LIFTOFF() {
  BLEdisable();
  if (millis() - liftoff_time >= 7000) {
    digitalWrite(status_pin01, HIGH);
    servo02.writeMicroseconds(servo02_open);
    servo03.writeMicroseconds(servo03_open);
    status01 = true;
  }
  if (millis() - liftoff_time >= 7500) {
    digitalWrite(status_pin01, HIGH);
    servo00.writeMicroseconds(servo00_open);
    servo01.writeMicroseconds(servo01_open);
    status00 = true;
  }
}

void EMERGENCY_MODE00(){
  BLEdisable();
  servo00.writeMicroseconds(servo00_open);
  servo01.writeMicroseconds(servo01_open);
  status00 = true;
}

void EMERGENCY_MODE01(){
  BLEdisable();
  servo02.writeMicroseconds(servo02_open);
  servo03.writeMicroseconds(servo03_open);
  status01 = true;
}

// Servo myServo;
// const int servoPin = 5;
// volatile int targetValue = 1500;
// volatile servo_min = 500;
// volatile servo_max = 2400;
// volatile open_position = 2400;
// volatile close_position = 500;

// int condition = stand_by;
// bool manual_control = false;
// bool bluetooth_control = false;

// bool directive = false;
// const int triggerTime = 0;
// const int time_to_the_peak = 7000; //stamicroseconds 1s = 1000ms

// bool voltage monitoring = false;
// unsigned long lastLedToggle = 0;
// bool ledState = false;
// int battery_interval = 1000;

// // スイッチ状態管理
// int switchPressedCounter = 0;
// const int debounceThreshold = 5;
// bool switchStable = false;          // 今の安定状態
// bool switchPrevStable = false;      // 前の安定状態
// bool switchJustPressed = false;     // 押された瞬間

// int flightrepeat = 0;
// const int repeatcount = 5;

// void status_check(){
//   bool go_nogo = digitalRead(flight_pin) == LOW;
//   if (go_nogo){
//     if (flightrepeat < repeatcount){
//       flightrepeat++;
//     }
//   }else{
//     if (flightrepeat > 0){
//       flightrepeat--;
//     }
//   }
//   if (flightrepeat >= repeatcount){
//     directive = true
//   }else {
//     directive = false
//   }
// }

// void servo_controll(){
//   if (condition == unlocking){
//     myServo.writeMicroseconds(open_position);
//     delay(2500);
//     condition = droping;
//   }else if(condition != lift_off | condition != rising | condition != droping) {
//     // myServo.writeMicroseconds(close_position);
//     int volume_value = analogRead(volume_pin);
//     if (switchJustPressed){
//       base_volume_value = volume_value;
//       base_servo_value = myServo.readMicroseconds();
//     }
//     if (manual_control){
//       int delta = volume_value - base_volume_value;
//       if (volume_value < base_volume_value){
//         delta_minus = map(volume_value, 0, base_volume_value, servo_min, base_servo_value);
//         myServo.writeMicroseconds(constrain((base_servo_value - delta_minus),500, 2400));
//       }else{
//         delta_plus = map(volume_value, base_volume_value, 2047, base_servo_value, servo_max)
//         myServo.writeMicroseconds(constrain((base_servo_value + delta_plus),500, 2400));
//       }
//     }else if (isConnected == true){
//         myServo.writeMicroseconds(target_position);
//     }
// }

// void manualmodecheck(){
//   bool raw = digitalRead(manual_switch) == LOW;
//   if (raw){
//     if (switchPressedCounter < debounceThreshold){
//       switchPressedCounter++;
//     }
//   }else{
//     if (switchPressedCounter > 0){
//       switchPressedCounter--;
//     }
//   }
//   // 状態更新
//   switchPrevStable = switchStable;
//   switchStable = (switchPressedCounter >= debounceThreshold);
//   // 押された瞬間だけ true にする
//   switchJustPressed = (switchStable && !switchPrevStable);

//   if (switchStable){
//     manual_control = true
//   }else{
//     manual_control = false
//   }
// }

void setup() {
  Serial.begin(115200);

  pinMode(signal_pin00, INPUT_PULLUP);
  pinMode(signal_pin01, INPUT_PULLUP);
  pinMode(status_pin00, OUTPUT);
  pinMode(status_pin01, OUTPUT);

  servo00.setPeriodHertz(50);
  servo01.setPeriodHertz(50);
  servo02.setPeriodHertz(50);
  servo03.setPeriodHertz(50);

  servo00.attach(servo00_pin, 500, 2400);
  servo01.attach(servo01_pin, 500, 2400);
  servo02.attach(servo02_pin, 500, 2500);
  servo03.attach(servo03_pin, 500, 2500);
}

void loop() {

  signal00 = (digitalRead(signal_pin00)) ? false : true;
  signal00 = (digitalRead(signal_pin01)) ? false : true;

  if (!signal00 || !signal01) {
    if (digitalRead(flight_pin) == HIGH) {
      if (flight == false) {
        return;
      } else {
        flight = false;
        STANDBY();
      }
    } else {
      if (flight == true) {
        return;
      } else {
        flight = true;
        liftoff_time = millis();
        LIFTOFF();
      }
    }
  }else if(signal00){
    EMERGENCY_MODE00();
  }else if(signal01){
    EMERGENCY_MODE01();
  }else{
    EMERGENCY_MODE00();
    EMERGENCY_MODE01();
  }

  digitalWrite(status_pin00, status00 ? HIGH : LOW);
  digitalWrite(status_pin01, status01 ? HIGH : LOW);

  updatemyBLE();
}
