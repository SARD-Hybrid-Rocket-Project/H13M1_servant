#include "myBLE.h"

// BLE接続状態監視
class MyServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer* pServer) {
    isConnected = true;
    // Serial.println("BLE Connected");
  }
  void onDisconnect(BLEServer* pServer) {
    isConnected = false;
    // Serial.println("BLE Disconnected");
  }
};

// BLE受信処理
class MyCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic *pCharacteristic) {
    String rxValue = String(pCharacteristic->getValue().c_str());
    rxValue.trim();  // 前後の空白除去
    if (rxValue.length() > 0) {
      if (isNumber(rxValue)) {
        int value = rxValue.toInt();
        value = constrain(value, 500, 2500); 
        servo00_value = (servo00_ctrl) ? servo00_close:targetValue;
        servo00_value = (servo01_ctrl) ? servo01_close:targetValue;
        servo00_value = (servo02_ctrl) ? servo02_close:targetValue;
        servo00_value = (servo03_ctrl) ? servo03_close:targetValue;
        // Serial.print("Received number (BLE): ");
        // Serial.println(value);
      } else if (rxValue.equalsIgnoreCase("DISARM")) {
        DISARM();
      } else if (rxValue.equalsIgnoreCase("ARM")) {
        ARM();
      } else if (rxValue.equalsIgnoreCase("servo00ctrl")){
        servo00_ctrl = (servo00_ctrl) ? false:true;
        servo02_ctrl = false;
        servo03_ctrl = false;
        targetValue = 1000;
        // Serial.println(String("servo00_ctrl: ") + servo00_ctrl);
      } else if (rxValue.equalsIgnoreCase("servo01ctrl")) {
        servo01_ctrl = (servo01_ctrl) ? false:true;
        servo02_ctrl = false;
        servo03_ctrl = false;
        targetValue = 1000;
        // Serial.println(String("servo01_ctrl: ") + servo01_ctrl);
      } else if (rxValue.equalsIgnoreCase("servo02ctrl")) {
        servo02_ctrl = (servo02_ctrl) ? false:true;
        servo00_ctrl = false;
        servo01_ctrl = false;
        targetValue = 1555;
        // Serial.println(String("servo02_ctrl: ") + servo02_ctrl);
      } else if (rxValue.equalsIgnoreCase("servo03ctrl")) {
        servo03_ctrl = (servo03_ctrl) ? false:true;
        servo00_ctrl = false;
        servo01_ctrl = false;
        targetValue = 1555;
        // Serial.println(String("servo03_ctrl: ") + servo03_ctrl);
      }
    }
  }

  bool isNumber(String str) {
    for (int i = 0; i < str.length(); i++) {
      if (!isDigit(str.charAt(i))) {
        return false;
      }
    }
    return true;
  }
};

void setupmyBLE() {
  if (!BLEable) return;

  BLEDevice::init("ESP32_Servo_BLE");
  BLEServer *pServer = BLEDevice::createServer();
  pServer->setCallbacks(new MyServerCallbacks());

  BLEService *pService = pServer->createService(SERVICE_UUID);
  BLECharacteristic *pCharacteristic = pService->createCharacteristic(
    CHARACTERISTIC_UUID,
    BLECharacteristic::PROPERTY_WRITE
  );
  pCharacteristic->setCallbacks(new MyCallbacks());
  pCharacteristic->addDescriptor(new BLE2902());

  pService->start();
  pServer->getAdvertising()->start();

  // Serial.println("BLE Servo Controller ready.");

}

// BLE を停止する関数
void stopmyBLE() {
  if (pServer) {
    pServer->getAdvertising()->stop(); // アドバタイズ停止
    BLEDevice::deinit(true);           // BLE スタックを完全停止
    pServer = nullptr;
    // Serial.println("BLE Stopped.");
  }
}

// loop などで bleable に応じて起動/停止を切り替える
void updatemyBLE() {
  static bool previousBLEable = false;

  if (BLEable && !previousBLEable) {
    // false → true に変わったら BLE 初期化
    setupmyBLE();
  } else if (!BLEable && previousBLEable) {
    // true → false に変わったら BLE 停止
    stopmyBLE();
  }

  previousBLEable = BLEable;
}