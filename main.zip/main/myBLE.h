#pragma once

#ifndef MYBLE_H
#define MYBLE_H

#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>

#define SERVICE_UUID        "4fafc201-1fb5-459e-8fcc-c5c9c331914b"
#define CHARACTERISTIC_UUID "beb5483e-36e1-4688-b7f5-ea07361b26a8"

BLEServer* pServer = nullptr;

extern bool BLEable;
bool isConnected = false;

extern int servo00_value;
extern int servo01_value;
extern int servo02_value;
extern int servo03_value;
extern bool servo00_ctrl;
extern bool servo01_ctrl;
extern bool servo02_ctrl;
extern bool servo03_ctrl;
extern const int servo00_close;
extern const int servo01_close;
extern const int servo02_close;
extern const int servo03_close;

int targetValue = 1000;

extern void DISARM();
extern void ARM();

void stopmyBLE();
void updatemyBLE(); 

#endif