// #include "myOLED.h"

// void setupOLED(){
//   if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
//     Serial.println(F("SSD1306 init failed"));
//     while (true);
//   }
//   display.clearDisplay();
//   display.setTextColor(SSD1306_WHITE);
// }

//it was written in "void loop"
// display.clearDisplay();
//   // 上部：Bluetoothロゴと接続状態
//   display.drawBitmap(0, 0, bluetooth_logo, 7, 12, SSD1306_WHITE);  // 左上にロゴ
//   display.setTextSize(1);
//   display.setCursor(9, 2);
//   display.println(isConnected ? "CONNECTED" : "NOTCONNECTED");
//   // バッテリー状態表示領域
//   display.setTextSize(1);
//   if (voltage monitoring){
//     //dispaly
//   }else{
//     unsigned long currentMillis = millis();
//     if (currentMillis - lastLedToggle >= battery_interval) {
//       lastLedToggle = currentMillis;
//       ledState = !ledState;
//       if (ledState) {
//         display.setCursor(92, 2);
//         display.println("NODATA");
//       } else {
//         display.drawBitmap(107, 0, battery_logo_000, 6, 12, SSD1306_WHITE);
//       }
//     }
//   }
//   // 中央〜下：PWM値と角度
//   // display.setTextSize(2);
//   // display.setCursor(0, 20);
//   // display.print("MS:");
//   // display.println(targetValue);
//   display.setTextSize(2);
//   display.setCursor(0, 20);
//   display.print("");
//   if (condition == stand_by){
//     display.println("STAND-BY");
//   }else if (consition == lift_off){
//     display.println("LIFT-OFF");
//   }else if (consition == rising){
//     display.println(RISING);
//   }else if (consition == unlocking){
//     display.println("UNLOCKING");
//   }else if (consition == droping){
//     display.println("DROPING");
//   }else{
//     display.println("NO DATA");
//   }
//   display.setCursor(0, 44);
//   // display.print("Ang:");
//   // display.println(angle);
//   display.print(myServo.read());
//   display.print("");
//   display.println("deg");
//   //残り時間表示(解放信号から解放動作までの残り時間)
//   display.setTextSize(3);
//   display.setCursor(75, 36);
//   display.print("");
//   if (!launched){
//     if (time_to_the_peak < 10){
//       display.println("0");
//     }
//     display.println(time_to_the_peak);
//   }else{
//     display.println("07");
//   }
//   display.setTextSize(2);
//   display.setCursor(92, 48);
//   display.println("sec");

//   display.display();

//   delay(100);