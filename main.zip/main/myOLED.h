// // #include <Wire.h>
// #include <Adafruit_GFX.h>
// #include <Adafruit_SSD1306.h>

// #define SCREEN_WIDTH 128
// #define SCREEN_HEIGHT 64
// #define OLED_RESET -1
// Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);


// // Bluetoothロゴ（8x12ドット）
// const unsigned char bluetooth_logo [] PROGMEM = {
//   0b00000000,
//   0b00011000,
//   0b00010100,
//   0b10010010,
//   0b01010100,
//   0b00111000,
//   0b00111000,
//   0b01010100,
//   0b10010010,
//   0b00010100,
//   0b00011000,
//   0b00000000
// };

// // batteryロゴ（6x12ドット）
// const unsigned char battery_logo_100 [] PROGMEM = {
//   0b000000,
//   0b001100,
//   0b111111,
//   0b111111,
//   0b111111,
//   0b111111,
//   0b111111,
//   0b111111,
//   0b111111,
//   0b111111,
//   0b111111,
//   0b000000
// };

// // batteryロゴ（6x12ドット）
// const unsigned char battery_logo_000 [] PROGMEM = {
//   0b000000,
//   0b001100,
//   0b111111,
//   0b100001,
//   0b100001,
//   0b100001,
//   0b100001,
//   0b100001,
//   0b100001,
//   0b100001,
//   0b111111,
//   0b000000
// };
